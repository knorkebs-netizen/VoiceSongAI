package com.voicesongai.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

private const val PROFILE_SECONDS = 30L

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoiceSongApp() }
    }
}

@Composable
fun VoiceSongApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var songUri by remember { mutableStateOf<Uri?>(null) }
    var recording by remember { mutableStateOf(false) }
    var secondsLeft by remember { mutableStateOf(PROFILE_SECONDS) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var profileFile by remember { mutableStateOf<File?>(null) }
    var status by remember { mutableStateOf("Bereit") }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var timer by remember { mutableStateOf<CountDownTimer?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        songUri = uri
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            status = "Song bereit"
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) status = "Mikrofon freigegeben – Aufnahme erneut starten" else status = "Mikrofonzugriff wird benötigt"
    }

    fun stopRecording(message: String = "Stimmaufnahme fertig") {
        timer?.cancel(); timer = null
        try { recorder?.stop() } catch (_: Exception) { }
        recorder?.release(); recorder = null
        recording = false
        secondsLeft = PROFILE_SECONDS
        status = message
    }

    fun startRecording() {
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        val file = File(context.filesDir, "voice_profile_${System.currentTimeMillis()}.m4a")
        val r = MediaRecorder(context)
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(192000)
            r.setAudioSamplingRate(48000)
            r.setOutputFile(file.absolutePath)
            r.prepare(); r.start()
            recorder = r; recordingFile = file; recording = true; secondsLeft = PROFILE_SECONDS
            status = "Sprich natürlich – noch 30 Sekunden"
            timer = object : CountDownTimer(PROFILE_SECONDS * 1000, 1000) {
                override fun onTick(ms: Long) { secondsLeft = (ms / 1000L) + 1; status = "Aufnahme läuft – ${secondsLeft}s" }
                override fun onFinish() { secondsLeft = 0; stopRecording("30-Sekunden-Profil aufgenommen") }
            }.start()
        } catch (e: Exception) {
            r.release(); recorder = null; recording = false
            status = "Aufnahme konnte nicht gestartet werden"
        }
    }

    fun createProfile() {
        val source = recordingFile ?: return
        val target = File(context.filesDir, "my_voice_profile.m4a")
        source.copyTo(target, overwrite = true)
        profileFile = target
        status = "Dein persönliches Stimmprofil ist gespeichert"
    }

    fun play(uri: Uri) {
        player?.release(); player = null
        player = MediaPlayer.create(context, uri)
        if (player == null) { status = "Audio konnte nicht abgespielt werden"; return }
        player?.setOnCompletionListener { status = "Wiedergabe fertig" }
        player?.start(); status = "Wiedergabe läuft …"
    }

    DisposableEffect(Unit) { onDispose { timer?.cancel(); recorder?.release(); player?.release() } }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("VoiceSong AI", style = MaterialTheme.typography.headlineLarge)
                Text("Deine Stimme → beliebige Gesangsmelodie", style = MaterialTheme.typography.bodyLarge)

                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("1 · Dein 30-Sekunden-Stimmprofil", style = MaterialTheme.typography.titleLarge)
                        Text("Sprich einen natürlichen Text. Nicht singen – die KI soll deinen echten Stimmklang lernen.")
                        if (recording) {
                            Text("${secondsLeft}s", style = MaterialTheme.typography.displaySmall)
                            LinearProgressIndicator(progress = { 1f - secondsLeft.toFloat() / PROFILE_SECONDS }, modifier = Modifier.fillMaxWidth())
                        }
                        Button(onClick = { if (recording) stopRecording() else startRecording() }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (recording) "Aufnahme stoppen" else "30 Sekunden aufnehmen")
                        }
                        if (recordingFile != null && !recording) {
                            OutlinedButton(onClick = { createProfile() }, modifier = Modifier.fillMaxWidth()) { Text("✨ Mein Stimmprofil erstellen") }
                        }
                        if (profileFile != null) Text("✓ Stimmprofil auf dem Gerät gespeichert")
                    }
                }

                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("2 · Song auswählen", style = MaterialTheme.typography.titleLarge)
                        Text(songUri?.lastPathSegment ?: "Noch kein Song ausgewählt")
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Song auswählen") }
                        OutlinedButton(onClick = { songUri?.let { play(it) } }, enabled = songUri != null, modifier = Modifier.fillMaxWidth()) { Text("▶ Song anhören") }
                    }
                }

                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("3 · Deine Stimme auf den Song", style = MaterialTheme.typography.titleLarge)
                        Text("Hier kommt als nächstes die echte Voice-Conversion: Melodie des Songs analysieren und mit deinem Stimmprofil neu singen lassen.")
                        Button(onClick = { status = "Voice-Conversion-Modul ist als nächster KI-Baustein vorbereitet" }, enabled = profileFile != null && songUri != null, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                            Text("🎤 Song mit meiner Stimme erzeugen")
                        }
                    }
                }

                Text(status, style = MaterialTheme.typography.bodyMedium)
                Text("v0.3 · Stimmprofil-Pipeline", style = MaterialTheme.typography.labelMedium, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}
